package tpp;

public class TPPException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 3334824488519317796L;

	public TPPException(String string) {
		super(string);
	}

}
