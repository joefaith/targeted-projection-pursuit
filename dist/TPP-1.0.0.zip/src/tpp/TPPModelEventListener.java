package tpp;

public interface TPPModelEventListener {
	public void modelChanged(TPPModelEvent e);

}
