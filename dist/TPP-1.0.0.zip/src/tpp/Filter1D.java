package tpp;

/** A filter for smoothing a 1D array of numbers. */
public interface Filter1D {

	public double[] filter(double[] a);

}
